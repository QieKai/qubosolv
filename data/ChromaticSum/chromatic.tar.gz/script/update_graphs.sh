#!/bin/bash
function updateK(){
  IFS=' '
  ary=($1)
  #for key in "${!ary[@]}"; do echo "$key ${ary[$key]}"; done
  filename="$2/${ary[0]}.alist"
  #echo $filename
  line="${ary[1]} ${ary[2]}"
  sed -i '' -e "1s/.*/$line/" $filename
}

function update_graphs(){
path="./"
while IFS='' read -r line || [[ -n "$line" ]]; do
    if [[ $line == *" "* ]]
      then
        updateK "$line" $path
    else
        path=$line
    fi
done < $1
}
update_graphs "graph_n_k.txt"
